
umount -f -l /mnt/cifs
mount -t cifs //192.168.5.225/ARCHIV /mnt/cifs --verbose -o user=alex,password=Gfcbntcm,iocharset=utf8

