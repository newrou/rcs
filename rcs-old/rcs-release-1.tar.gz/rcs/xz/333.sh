
#if mount | grep /mnt/cifs 
#then echo "Замонтирован"
#else echo "Не замонтирован"
#fi

while [ -e 111 ]
do
 sleep 1
 echo "заблокирован"
done
echo "открыт"

