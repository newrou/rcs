<?php

 function MakeConf($fname)
 {
  $fp = fopen('/etc/rcs/reserv.conf', 'wt');
  fwrite($fp,"* * * * * php /etc/rcs/make-conf.php >> /etc/rcs/log/all.log 2>> /etc/rcs/log/err.log\n");
  $xml = simplexml_load_file($fname);
  foreach($xml->resource as $res)
   {
    $id = $res->id;
    $rs = $res->res;
    $user = $res->user;
    $passwd = $res->passwd;
    $dest = $res->dest;
    $time = $res->time;
    $ncopy = $res->ncopy;
    $comment = $res->comment;
    fwrite($fp,"$time /etc/rcs/rsync-res.sh $id $rs $dest $ncopy \"$user\" \"$passwd\" >> /etc/rcs/log/all.log 2>> /etc/rcs/log/err.log\n");
   }
    fclose($fp);
 }

 MakeConf("/etc/rcs/reserv-conf.xml");
 system("/usr/sbin/service cron restart");
