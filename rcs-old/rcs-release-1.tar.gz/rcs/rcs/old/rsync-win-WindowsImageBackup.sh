
rsync -alrvP --exclude=old /mnt/WindowsImageBackup /home/max/Archiv
