
rsync -alrvP --exclude=distrib /mnt/fs/shared /home/max/Archiv/fs
rsync -alrvP /mnt/fs/max /home/max/Archiv/fs
rsync -alrvP /mnt/fs/Зыбина /home/max/Archiv/fs
rsync -alrvP /mnt/fs/Производственный\ отдел /home/max/Archiv/fs
