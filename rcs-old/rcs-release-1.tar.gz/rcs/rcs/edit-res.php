<?php

 function PrintRes($fname,$x)
 {
//  echo "$fname";
  echo "<table border=1>\n";
  $xml = simplexml_load_file($fname);

//  echo $xml->asXML();
  foreach($xml->resource as $res)
   {
    $id = $res->id;
    if($id == $x)
     {
      $rs = $res->res;
      $user = $res->user;
      $passwd = $res->passwd;
      $dest = $res->dest;
      $time = $res->time;
      $ncopy = $res->ncopy;
      $comment = $res->comment;
      echo " <form action=\"save-res.php\" method=POST> <input type=hidden name=id value=\"$id\"><br>\n";
      echo " <table> ";
      echo " <tr><td>ресурс: </td><td><input type=text name=rs value=\"$rs\"></td></tr>\n";
      echo " <tr><td>пользователь: </td><td><input type=text name=user value=\"$user\"></td></tr>\n";
      echo " <tr><td>пароль: </td><td><input type=text name=passwd value=\"$passwd\"></td></tr>\n";
      echo " <tr><td>хранилище: </td><td><input type=text name=dest value=\"$dest\"></td></tr>\n";
      echo " <tr><td>периодичность: </td><td><input type=text name=time value=\"$time\"></td></tr>\n";
      echo " <tr><td>количество копий: </td><td><input type=text name=ncopy value=\"$ncopy\"></td></tr>\n";
      echo " <tr><td>комментарий: </td><td><input type=text name=comment value=\"$comment\"></td></tr>\n";
      echo " </table><input type=submit value=\"Сохранить\"><br>\n";
      return;
     }
   }
 echo " <h3>Ресурс не найден!</h3>\n";
 echo " <a href=\".\">Продолжить</a> <br>\n";
 }
 
 function AddRes($id)
  {
      $rs = "";
      $user = "";
      $passwd = "";
      $dest = "";
      $time = "* * * * *";
      $ncopy = "1";
      $comment = "";
      echo " <form action=\"save-res.php\" method=POST> <input type=hidden name=id value=\"$id\"><br>\n";
      echo " <table> ";
      echo " <tr><td>ресурс: </td><td><input type=text name=rs value=\"$rs\"></td></tr>\n";
      echo " <tr><td>пользователь: </td><td><input type=text name=user value=\"$user\"></td></tr>\n";
      echo " <tr><td>пароль: </td><td><input type=text name=passwd value=\"$passwd\"></td></tr>\n";
      echo " <tr><td>хранилище: </td><td><input type=text name=dest value=\"$dest\"></td></tr>\n";
      echo " <tr><td>периодичность: </td><td><input type=text name=time value=\"$time\"></td></tr>\n";
      echo " <tr><td>количество копий: </td><td><input type=text name=ncopy value=\"$ncopy\"></td></tr>\n";
      echo " <tr><td>комментарий: </td><td><input type=text name=comment value=\"$comment\"></td></tr>\n";
      echo " </table><input type=submit value=\"Сохранить\"><br>\n";
  }
 
 $id = $_GET['id'];
 echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf8\"><html><body>";
 echo "<h1><a href=\".\">Сервер резервного копирования.</a></h1>";
 echo "<h2>Редактирование ресурса: $id</h2>";
 if($id == 'new') $id = AddRes($id);
  else PrintRes("/etc/rcs/reserv-conf.xml",$id);
 echo "</body></html>";
?>
