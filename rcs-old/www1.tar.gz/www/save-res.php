<?php

 function PrintRes($fname,$x)
 {
//  echo "$fname";
  echo "<table border=1>\n";
  $xml = simplexml_load_file($fname);

  if($x == 'new') 
   {
    $t = (string)time();
    $id = "res$t";
    $x = $id;
    $node = $xml->addChild("resource","");
    $node->addChild("id","$id");
    $node->addChild("res","");
    $node->addChild("user","");
    $node->addChild("passwd","");
    $node->addChild("dest","");
    $node->addChild("time","");
    $node->addChild("ncopy","");
    $node->addChild("comment","");
    file_put_contents('/var/www/new.xml',$xml->asXML());
   }

//  echo $xml->asXML();
  foreach($xml->resource as $res)
   {
    $id = $res->id;
    if($id == $x)
     {
      $rs = $_POST['rs'];
      $user = $_POST['user'];
      $passwd = $_POST['passwd'];
      $dest = $_POST['dest'];
      $time = $_POST['time'];
      $ncopy = $_POST['ncopy'];
      $comment = $_POST['comment'];

      $res->res = $rs;
      $res->user = $user;
      $res->passwd = $passwd;
      $res->dest = $dest;
      $res->time = $time;
      $res->ncopy = $ncopy;
      $res->comment = $comment;

      echo " <table> ";
      echo " <tr><td>ресурс: </td><td>$rs</td></tr>\n";
      echo " <tr><td>пользователь: </td><td>$user</td></tr>\n";
      echo " <tr><td>пароль: </td><td>$passwd</td></tr>\n";
      echo " <tr><td>хранилище: </td><td>$dest</td></tr>\n";
      echo " <tr><td>периодичность: </td><td>$time</td></tr>\n";
      echo " <tr><td>количество копий: </td><td>$ncopy</td></tr>\n";
      echo " <tr><td>комментарий: </td><td>$comment</td></tr>\n";
      echo " </table> <a href=\"/\">Продолжить</a> <br>\n";
      
//      echo (string )$xml->asXML();
      file_put_contents($fname,$xml->asXML());
      return;
     }
   }
 echo " <h3>Ресурс не найден!</h3>\n";
 }

 $id = $_POST['id'];

 echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf8\"><html><body>";
 echo "<h1><a href=\"/\">Сервер резервного копирования.</a></h1>";
 echo "<h2>Редактирование ресурса: $id </h2>";
 PrintRes("/var/www/reserv-conf.xml",$id);
 echo "</body></html>";
?>
