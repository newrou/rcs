<?php
 function PrintRes($fname)
 {
//  echo "$fname";
  echo "<table border=1>\n<tr> <td>ресурс</td> <td>хранилище</td> <td>периодичность</td> <td>комментарий</td></tr>\n";
  $xml = simplexml_load_file($fname);

  foreach($xml->resource as $res)
   {
    $id = $res->id;
    $rs = $res->res;
    $dest = $res->dest;
    $time = $res->time;
    $comment = $res->comment;
    echo "<tr>";
    echo " <td><a href=\"/edit-res.php?id=$id\">&nbsp;$rs&nbsp;</a></td>";
    echo " <td>&nbsp;$dest&nbsp;</td>";
    echo " <td>&nbsp;$time&nbsp;</td>";
    echo " <td>&nbsp;$comment&nbsp;</td>";
    echo "</tr>\n";
   }
 echo "</table>";
 //  file_put_contents('/var/www/new.xml',$xml->asXML());
 }

 echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf8\"><html><body>";
 echo "<h1>Сервер резервного копирования.</h1>";
 echo "<h2>Список ресурсов.</h2>";
 PrintRes("/var/www/reserv-conf.xml");
 echo "<h3><a href=\"edit-res.php?id=new\">Добавить</a></h3>";
 echo "</body></html>";
?>
