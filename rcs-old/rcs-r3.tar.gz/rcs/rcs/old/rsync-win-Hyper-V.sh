
dt=`date +"%d.%m.%y"`
rsync -alrvP --exclude=old /mnt/Hyper-V /home/max/Archiv

