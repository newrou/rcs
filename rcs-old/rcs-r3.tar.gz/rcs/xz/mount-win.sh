# $1 - сетевой ресурс   $2 - хранилище

umount -f -l --fake /mnt/cifs
mount -t cifs $1 /mnt/cifs --verbose -o user=MSmirnov,password=\[htydfv,iocharset=utf8
mkdir -p /Archiv/$2
rsync -alrvP /mnt/cifs/* /Archiv/$2
umount -f -l --fake /mnt/cifs

