
n=`wc -l <$1`
x=`echo $n"-"$2"-1" | bc`

if [ $x -gt 0 ]
then
lst=`tail -n +2 $1 | head -n $x | cut -d" " -f1`

for f in $lst 
do
 echo "Удаляю "$f
done
fi
