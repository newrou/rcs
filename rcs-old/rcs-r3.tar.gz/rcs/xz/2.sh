#!/bin/bash
/etc/rcs/rsync-res.sh res1342780375 //192.168.5.229/GAMES Игры 2 "user" "uuuu"
/etc/rcs/rsync-res.sh res1342780486 //192.168.5.229/пример Example 1 "user" ""

