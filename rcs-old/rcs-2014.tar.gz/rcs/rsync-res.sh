#!/bin/bash

res_id=$1
res=$2
dest=$3
ncopy=$4
res_user=$5
res_passwd=$6
tm=`date "+%d.%m.%Y-%H-%M"`

while [ -e /etc/rcs/lock/$res_id.lock ]
do
 sleep 100
 echo "заблокирован: $res_id $dest $res"
done
echo "открыт: $res_id $dest $res"

echo 1 > /etc/rcs/lock/$res_id.lock
echo $tm": WORK rsync-res.sh "$res_id
echo $tm": "$res_id >> /etc/rcs/log/rsync-res.log

mkdir -p /mnt/$res_id
umount -f -l --fake /mnt/$res_id

#until mount | grep /mnt/$res_id > /dev/null
#do
 sleep 12
# echo "Не замонтирован: $res_id $dest $res"
 mount -v -t cifs "$res" /mnt/$res_id --verbose -o ro,user=$res_user,password=$res_passwd,iocharset=utf8
#done
#echo "Замонтирован: $res_id $dest $res"

mkdir -p /Archiv/$res_id
/sbin/zfs create Archiv/$res_id
rsync -alrvP --delete /mnt/$res_id/* /Archiv/$res_id/
umount -f -l --fake /mnt/$res_id

ln -n -s /Archiv/$res_id /Archiv/Share/$dest
rm -f /etc/rcs/lock/$res_id.lock

echo "Добавляем снимок Archiv/"$res_id"@"$tm >> /etc/rcs/log/zpool.log
/sbin/zfs snapshot Archiv/$res_id@$tm >> /etc/rcs/log/zpool.log
echo "Создаем клон Archiv/"$res_id"-"$tm >> /etc/rcs/log/zpool.log
/sbin/zfs clone Archiv/$res_id@$tm Archiv/$res_id-$tm >> /etc/rcs/log/zpool.log
ln -n -s /Archiv/$res_id-$tm /Archiv/Share/$dest-$tm

/sbin/zfs list -r -t snapshot -o name,creation Archiv/$res_id > /etc/rcs/log/$res_id.snapshots
n=`wc -l < /etc/rcs/log/$res_id.snapshots`
x=`echo $n"-"$ncopy"-1" | bc`


if [ $x -gt 0 ]
then
lst=`tail -n +2 /etc/rcs/log/$res_id.snapshots | head -n $x | cut -d" " -f1`

echo "ncopy = "$ncopy" x = "$x >> /etc/rcs/log/zpool.log
#echo $lst >> /etc/rcs/log/zpool.log

for f in $lst 
do
 tm_id=`echo $f | cut -d"@" -f2`
 echo "Удаляем клон Archiv/"$res_id"-"$tm_id >> /etc/rcs/log/zpool.log
 /sbin/zfs destroy -R Archiv/$res_id-$tm_id >> /etc/rcs/log/zpool.log
 echo "Удаляем снимок "$f >> /etc/rcs/log/zpool.log
 /sbin/zfs destroy -R $f >> /etc/rcs/log/zpool.log
 rm -f /Archiv/Share/$dest-$tm_id
done
fi
date >> /etc/rcs/log/zpool.log
