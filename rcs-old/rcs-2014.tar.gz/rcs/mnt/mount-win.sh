

#/etc/rcs/rsync-res.sh res1342940141 "//192.168.0.13/WindowsImageBackup" "CD2" 1 "администратор" "Flvby1" >> /etc/rcs/log/all.log 2>> /etc/rcs/log/err.log
#/etc/rcs/rsync-res.sh res1342941064 "//192.168.0.101/Shared" "Shared" 7 "администратор" "Flvby1" >> /etc/rcs/log/all.log 2>> /etc/rcs/log/err.log


#mount -t cifs //192.168.0.13/WindowsImageBackup /mnt/xz --verbose -o ro,user=администратор,password=Flvby1,iocharset=utf8
mount -t cifs //192.168.0.101/Shared /mnt/xz --verbose -o ro,user=администратор,password=Flvby1,iocharset=utf8

##mount -t cifs //192.168.0.30/Archiv /mnt/xz --verbose -o ro,user=max,password=Flvby1,iocharset=utf8
#mount -t cifs //192.168.0.30/Archiv /mnt/xz --verbose -o iocharset=utf8
