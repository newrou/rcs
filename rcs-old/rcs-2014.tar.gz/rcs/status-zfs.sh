
zpool status
zfs list -t snapshot
zfs list -o space
