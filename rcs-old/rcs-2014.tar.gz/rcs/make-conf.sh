#!/bin/bash

service cron stop
php /etc/rcs/make-conf.php >> /etc/rcs/log/all.log 2>> /etc/rcs/log/err.log
#/etc/init.d/cron restart
service cron start
