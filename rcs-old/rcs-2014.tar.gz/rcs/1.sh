
date "+%d.%m.%Y-%H-%M"

###/etc/rcs/rsync-res.sh res1342936516 "//192.168.0.59/backup1c" "1С_База" 7 "администратор" "Flvby1" >> /etc/rcs/log/all.log 2>> /etc/rcs/log/err.log

#/etc/rcs/rsync-res.sh res1342940141 "//192.168.0.13/WindowsImageBackup" "CD2" 1 "администратор" "Flvby1" >> /etc/rcs/log/all.log 2>> /etc/rcs/log/err.log

###/etc/rcs/rsync-res.sh res1342940523 "//192.168.0.101/Производственный отдел" "Производственный_отдел" 7 "администратор" "Flvby1" >> /etc/rcs/log/all.log 2>> /etc/rcs/log/err.log

#/etc/rcs/rsync-res.sh res1342941064 "//192.168.0.101/Shared" "Shared" 7 "администратор" "Flvby1"

###/etc/rcs/rsync-res.sh res1391651897 "//192.168.0.101/Уркина" "Уркина" 2 "администратор" "Flvby1" >> /etc/rcs/log/all.log 2>> /etc/rcs/log/err.log
