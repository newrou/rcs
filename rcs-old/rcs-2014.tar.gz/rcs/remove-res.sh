#!/bin/bash

zfs destroy -R -f Archiv/$1
