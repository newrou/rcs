
umount -f -l cifs
mount -t cifs //192.168.0.101/shared cifs --verbose -o user=администратор,password=Flvby1,iocharset=utf8

