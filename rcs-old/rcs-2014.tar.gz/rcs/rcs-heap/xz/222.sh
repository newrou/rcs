
#if mount | grep /mnt/cifs 
#then echo "Замонтирован"
#else echo "Не замонтирован"
#fi

until mount | grep /mnt/cifs > /dev/null
do
 sleep 1
 echo "Не замонтирован"
done
echo "Замонтирован"

