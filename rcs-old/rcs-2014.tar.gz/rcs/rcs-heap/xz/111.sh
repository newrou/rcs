
if mount | grep -v /mnt/cifs > /dev/null
then echo "Не замонтирован"
else echo "Замонтирован"
fi


