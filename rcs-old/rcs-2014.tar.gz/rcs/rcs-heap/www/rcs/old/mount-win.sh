
mount -t cifs //192.168.0.34/Bases /mnt/Bases --verbose -o user=MSmirnov,password=\[htydfv,iocharset=utf8

mount -t cifs //192.168.0.13/Hyper-V /mnt/Hyper-V --verbose -o user=MSmirnov,password=\[htydfv,iocharset=utf8
mount -t cifs //192.168.0.13/WindowsImageBackup /mnt/WindowsImageBackup --verbose -o user=MSmirnov,password=\[htydfv,iocharset=utf8

mount -t cifs //192.168.0.101/shared /mnt/fs/shared --verbose -o user=MSmirnov,password=\[htydfv,iocharset=utf8
mount -t cifs //192.168.0.101/max /mnt/fs/max --verbose -o user=MSmirnov,password=\[htydfv,iocharset=utf8
mount -t cifs //192.168.0.101/Зыбина /mnt/fs/Зыбина --verbose -o user=MSmirnov,password=\[htydfv,iocharset=utf8
mount -t cifs //192.168.0.101/Производственный\ отдел /mnt/fs/Производственный\ отдел --verbose -o user=MSmirnov,password=\[htydfv,iocharset=utf8

