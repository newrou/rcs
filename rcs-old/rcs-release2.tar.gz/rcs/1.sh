#* * * * * /etc/rcs/make-conf.sh >> /etc/rcs/log/all.log 2>> /etc/rcs/log/err.log
#1 23 * * * /etc/rcs/rsync-res.sh res1342936516 "//192.168.0.34/Bases" "1С_База" 5 "администратор" "Flvby1" >> /etc/rcs/log/all.log 2>> /etc/rcs/log/err.log
#1 0 */14 * * /etc/rcs/rsync-res.sh res1342939129 "//192.168.0.34/Bases" "1С_База_за_месяц" 6 "администратор" "Flvby1" >> /etc/rcs/log/all.log 2>> /etc/rcs/log/err.log
/etc/rcs/rsync-res.sh res1342939745 "//192.168.0.13/Hyper-V" "TS" 2 "администратор" "Flvby1" >> /etc/rcs/log/all.log 2>> /etc/rcs/log/err.log
/etc/rcs/rsync-res.sh res1342940141 "//192.168.0.13/WindowsImageBackup" "CD2" 2 "администратор" "Flvby1" >> /etc/rcs/log/all.log 2>> /etc/rcs/log/err.log
#/etc/rcs/rsync-res.sh res1342940523 "//192.168.0.101/Производственный отдел" "Производственный_отдел" 2 "администратор" "Flvby1" >> /etc/rcs/log/all.log 2>> /etc/rcs/log/err.log 
#1 3 * * * /etc/rcs/rsync-res.sh res1342941064 "//192.168.0.101/Shared" "Shared" 2 "администратор" "Flvby1" >> /etc/rcs/log/all.log 2>> /etc/rcs/log/err.log
