
dt=`date +"%d.%m.%y"`
rsync -alrvP --exclude=old /mnt/Bases/* /home/max/Archiv/Bases/Bases-$dt

