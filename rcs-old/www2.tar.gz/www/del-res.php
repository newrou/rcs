<?php

 function PrintRes($fname,$x)
 {
//  echo "$fname";
  echo "<table border=1>\n";
  $xml = simplexml_load_file($fname);

//  echo $xml->asXML();
  $i=0;
  foreach($xml->resource as $res)
   {
    $id = $res->id;
    if($id == $x)
     {
      $rs = $res->res;
      $user = $res->user;
      $passwd = $res->passwd;
      $dest = $res->dest;
      $time = $res->time;
      $ncopy = $res->ncopy;
      $comment = $res->comment;

      echo " <table> ";
      echo " <tr><td>ресурс: </td><td>$rs</td></tr>\n";
      echo " <tr><td>пользователь: </td><td>$user</td></tr>\n";
      echo " <tr><td>пароль: </td><td>$passwd</td></tr>\n";
      echo " <tr><td>хранилище: </td><td>$dest</td></tr>\n";
      echo " <tr><td>периодичность: </td><td>$time</td></tr>\n";
      echo " <tr><td>количество копий: </td><td>$ncopy</td></tr>\n";
      echo " <tr><td>комментарий: </td><td>$comment</td></tr>\n";
      echo " </table> <a href=\"/\">Продолжить</a> <br>\n";
      unset($xml->resource[$i]);
//      echo (string )$xml->asXML();
      file_put_contents($fname,$xml->asXML());
      return;
     }
    $i++;
   }
 echo " <h3>Ресурс не найден!</h3>\n";
 }

 $id = $_GET['id'];

 echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf8\"><html><body>";
 echo "<h1><a href=\"/\">Сервер резервного копирования.</a></h1>";
 echo "<h2>Удаление ресурса: $id </h2>";
 PrintRes("/var/www/reserv-conf.xml",$id);
 echo "</body></html>";
?>
